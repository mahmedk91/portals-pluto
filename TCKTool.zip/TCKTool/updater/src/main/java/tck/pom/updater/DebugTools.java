package tck.pom.updater;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Contain toString() methods to convert xml tags modified in the TCK to
 * meaningful log output
 * 
 * @author ahmed
 */
public class DebugTools {

   private String newModuleName;

   public DebugTools(String newModuleName) {
      this.newModuleName = newModuleName;
   }

   /**
    * toString() method for <fl:file> tag for debugging
    */
   public String fileTagToString(Element newFile) {
      StringBuilder newFileTag = new StringBuilder();
      newFileTag.append("\n...\n<").append(newFile.getNodeName()).append(">")
            .append(newFile.getTextContent()).append("</")
            .append(newFile.getNodeName()).append(">\n...");
      return newFileTag.toString();
   }

   /**
    * toString() method for update in includeArtifactIds tag for debugging
    */
   public String artifactIdListUpdateToString(Node includeArtifactIds) {
      StringBuilder newArtifactListUpdate = new StringBuilder();
      newArtifactListUpdate.append("\n...\n<")
            .append(includeArtifactIds.getNodeName()).append(">")
            .append("\n   ...\n   ,tck-").append(newModuleName)
            .append("\n   ...\n</").append(includeArtifactIds.getNodeName())
            .append(">\n...");
      return newArtifactListUpdate.toString();
   }

   /**
    * toString() method for dependency Tag for debugging
    */
   public String dependencyToString(Element newDependency) {
      StringBuilder newDependencyTag = new StringBuilder();
      newDependencyTag.append("\n...\n<").append(newDependency.getTagName())
            .append(">");
      NodeList childNodes = newDependency.getChildNodes();
      for (int i = 0; i < childNodes.getLength(); i++) {
         Node childNode = childNodes.item(i);
         newDependencyTag.append("\n   <").append(childNode.getNodeName())
               .append(">").append(childNode.getTextContent()).append("</")
               .append(childNode.getNodeName()).append(">");
      }
      newDependencyTag.append("\n</").append(newDependency.getTagName())
            .append(">\n...");
      return newDependencyTag.toString();
   }

   /**
    * toString() method for module Tag for debugging
    */
   public String moduleToString(Element newModule) {
      StringBuilder newModuleTag = new StringBuilder();
      newModuleTag.append("\n...\n<").append(newModule.getTagName()).append(">")
            .append(newModule.getTextContent()).append("</")
            .append(newModule.getTagName()).append(">\n...");
      return newModuleTag.toString();
   }

}
