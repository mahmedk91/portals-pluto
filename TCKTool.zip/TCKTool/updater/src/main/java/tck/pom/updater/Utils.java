package tck.pom.updater;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;

/**
 * Util methods to backup old xml files and to save new ones 
 * @author ahmed
 */
public class Utils {
   
   public static final String TCK_POM_PATH          = "/pom.xml";
   public static final String DEPLOY_POM_PATH       = "/deploy/pom.xml";
   public static final String DRIVER_POM_PATH       = "/driver/pom.xml";
   public static final String DRIVER_PAGEFILES_PATH = "/driver/src/main/resources/xml-resources/pageFiles.xml";
   public static final String DRIVER_TESTFILES_PATH = "/driver/src/main/resources/xml-resources/testFiles.xml";
   
   private Transformer transformer;
   private String tckDirectory;
   
   public Utils(Transformer transformer, String tckDirectory) {
      this.transformer = transformer;
      this.tckDirectory = tckDirectory;
   }
   
   /**
    * rewrite the old XML File with the new XML File
    */
   public void transformXML(Document newXmlFile, String xmlFilePath) {
      try {
         // Set the left indent for the output pom file, so as to remain
         // consistent with the format.
         transformer.setOutputProperty(OutputKeys.INDENT, "yes");
         transformer.setOutputProperty(
               "{http://xml.apache.org/xslt}indent-amount", "3");

         // update the xml File with the new one
         DOMSource source = new DOMSource(newXmlFile);
         StreamResult result = new StreamResult(
               new File(xmlFilePath));
         transformer.transform(source, result);
      } catch (TransformerException e) {
         System.out.println("Error while saving " + xmlFilePath
               + ". Aborting execution now...");
         e.printStackTrace();
         System.exit(0);
      }
   }
   
   /**
    * Creates a backup of all xml files that are going to be changed in "backup" folder.
    */
   public void createBackup() throws IOException {
      new File("backup/portlet-tck_3.0/deploy").mkdirs();
      new File("backup/portlet-tck_3.0/driver/src/main/resources/xml-resources").mkdirs();
      String backupTCKDirectory = "backup/portlet-tck_3.0";
      copyFile(tckDirectory+TCK_POM_PATH, backupTCKDirectory+TCK_POM_PATH);
      copyFile(tckDirectory+DEPLOY_POM_PATH, backupTCKDirectory+DEPLOY_POM_PATH);
      copyFile(tckDirectory+DRIVER_POM_PATH, backupTCKDirectory+DRIVER_POM_PATH);
      copyFile(tckDirectory+DRIVER_PAGEFILES_PATH, backupTCKDirectory+DRIVER_PAGEFILES_PATH);
      copyFile(tckDirectory+DRIVER_TESTFILES_PATH, backupTCKDirectory+DRIVER_TESTFILES_PATH);
   }
   
   /**
    * Copies a file from source path to destination
    */
   public void copyFile(String source, String destination) throws IOException{
      Files.copy(new File(source).toPath(), new File(destination).toPath(), StandardCopyOption.REPLACE_EXISTING);
   }
   
}
