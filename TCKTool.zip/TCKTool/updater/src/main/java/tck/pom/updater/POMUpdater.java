package tck.pom.updater;

import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import static tck.pom.updater.Utils.*;

/**
 * Adds new module in the tck files - 
 * /pom.xml 
 * /deploy/pom.xml 
 * /driver/pom.xml
 * /driver/src/main/resources/xml-resources/pageFiles.xml
 * /driver/src/main/resources/xml-resources/testFiles.xml
 * 
 * @author ahmed
 */
public class POMUpdater {

   // Name of the new module to be added. Example - "V3PortletParametersTests"
   private static String     moduleName = null;

   // Location of portlet-tck_3.0 directory. Example -
   // "C:\Users\...\workspace\pluto\portlet-tck_3.0"
   private static String     tckDirectory;

   // debugTools to produce xml tag output in the console log.
   private static DebugTools debugTools;

   // Utils to save new xml files, backup existing xml files which we want to
   // update.
   private static Utils      utils;

   public static void main(String argv[]) throws IOException, SAXException,
         ParserConfigurationException, TransformerException {

      try {
         String pathToNewModule = argv[0];
         String[] pathBreakDown = pathToNewModule.split("portlet-tck_3.0");
         tckDirectory = pathBreakDown[0] + "portlet-tck_3.0";
         moduleName = pathBreakDown[1];
         moduleName = moduleName.replace("/", "");
         moduleName = moduleName.replace("\\", "");
         debugTools = new DebugTools(moduleName);
      } catch (Exception e) {
         e.printStackTrace();
         System.exit(0);
      }

      System.out.println("TCK Directory is: " + tckDirectory);
      System.out.println("New Module name is: " + moduleName);

      DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = transformerFactory.newTransformer();
      utils = new Utils(transformer, tckDirectory);

      Document newModulePom = docBuilder.parse("Skeleton_POM.xml");
      Document tckPom = docBuilder.parse(tckDirectory + TCK_POM_PATH);
      Document deployPom = docBuilder.parse(tckDirectory + DEPLOY_POM_PATH);
      Document driverPom = docBuilder.parse(tckDirectory + DRIVER_POM_PATH);
      Document driverPageFile = docBuilder
            .parse(tckDirectory + DRIVER_PAGEFILES_PATH);
      Document driverTestFile = docBuilder
            .parse(tckDirectory + DRIVER_TESTFILES_PATH);

      utils.createBackup();

      createPomForNewModule(newModulePom, argv[0]);
      addModuleToTckPom(tckPom);
      addModuleToDeployPom(deployPom);
      addModuleToDriverPom(driverPom);
      addModuleToTestFiles(driverPageFile, "pages", DRIVER_PAGEFILES_PATH);
      addModuleToTestFiles(driverTestFile, "tests", DRIVER_TESTFILES_PATH);
   }

   /**
    * Creates pom.xml for the new module
    */
   private static void createPomForNewModule(Document newModulePom,
         String pathToNewModule) throws IOException {

      System.out.println("\n");

      // Get the artifactId tag of this pom i.e. - "<artifactId></artifactId>"
      // tag
      Node artifactId = newModulePom.getElementsByTagName("artifactId").item(1);

      // Set the artifact id to "tck-newModule"
      artifactId.setTextContent("tck-" + moduleName);

      // create a new pom.xml in the new module directory of TCK
      utils.transformXML(newModulePom, "Skeleton_POM.xml");
      
      utils.copyFile("Skeleton_POM.xml", pathToNewModule + "/pom.xml");

      System.out.println("Successfully created new pom.xml in "
            + pathToNewModule + " for " + moduleName + " with artifact id: "
            + artifactId.getTextContent());

   }

   /**
    * Adds the new module page and test file to pageFiles.xml and testFiles.xml
    * respectively.
    */
   private static void addModuleToTestFiles(Document file, String type,
         String path) {
      System.out.println("\n");

      // Get the file list i.e. - "<fl:filelist></fl:filelist>" tag
      Node fileList = file.getElementsByTagName("fl:filelist").item(0);

      // Make a new "<fl:file>tck-newModule-type.xml</fl:file>" tag
      Element newFile = file.createElement("fl:file");
      newFile.setTextContent("tck-" + moduleName + "-" + type + ".xml");

      // Insert the new module's file at the end of file list
      fileList.appendChild(newFile);

      // rewrite the old xml file with the new updated xml file
      utils.transformXML(file, tckDirectory + path);

      System.out.println("Successfully added following XML to portlet-tck_3.0"
            + path + " - " + debugTools.fileTagToString(newFile));
   }

   /**
    * Adds the new module to Driver POM
    */
   private static void addModuleToDriverPom(Document driverPom) {
      System.out.println("\n");

      // Get the dependency list i.e. - "<dependencies></dependencies>" element
      // of the pom
      Node deployDependencies = driverPom.getElementsByTagName("dependencies")
            .item(0);

      // Make a new "<dependency>newModule</dependency>" tag
      Element newDependency = driverPom.createElement("dependency");
      Element groupId = driverPom.createElement("groupId");
      groupId.setTextContent("${project.groupId}");
      Element artifactId = driverPom.createElement("artifactId");
      artifactId.setTextContent("tck-" + moduleName);
      Element version = driverPom.createElement("version");
      version.setTextContent("${project.version}");
      Element type = driverPom.createElement("type");
      type.setTextContent("war");
      newDependency.appendChild(groupId);
      newDependency.appendChild(artifactId);
      newDependency.appendChild(version);
      newDependency.appendChild(type);

      // Insert the new module at the end of dependency list
      deployDependencies.appendChild(newDependency);

      // Get the list of Artifact ids from plugins tag
      Node includeArtifactIds = driverPom
            .getElementsByTagName("includeArtifactIds").item(0);
      String listOfAtrifactIds = includeArtifactIds.getTextContent();

      // Add the new module's artifact id in the list
      listOfAtrifactIds = listOfAtrifactIds + "   ,tck-" + moduleName
            + "\n                     ";
      includeArtifactIds.setTextContent(listOfAtrifactIds);

      // rewrite the old pom with the new updated pom
      utils.transformXML(driverPom, tckDirectory + DRIVER_POM_PATH);

      System.out.println(
            "Successfully added following XML to portlet-tck_3.0/driver/pom.xml - "
                  + debugTools.dependencyToString(newDependency) + debugTools
                        .artifactIdListUpdateToString(includeArtifactIds));
   }

   /**
    * Adds the new module to Deploy POM
    */
   private static void addModuleToDeployPom(Document deployPom)
         throws TransformerException {
      System.out.println("\n");

      // Get the dependency list i.e. - "<dependencies></dependencies>" element
      // of the pom
      Node deployDependencies = deployPom.getElementsByTagName("dependencies")
            .item(0);

      // Make a new "<dependency>newModule</dependency>" tag
      Element newDependency = deployPom.createElement("dependency");
      Element groupId = deployPom.createElement("groupId");
      groupId.setTextContent("${project.groupId}");
      Element artifactId = deployPom.createElement("artifactId");
      artifactId.setTextContent("tck-" + moduleName);
      Element version = deployPom.createElement("version");
      version.setTextContent("${project.version}");
      Element type = deployPom.createElement("type");
      type.setTextContent("war");
      newDependency.appendChild(groupId);
      newDependency.appendChild(artifactId);
      newDependency.appendChild(version);
      newDependency.appendChild(type);

      // Get the <dependency>deploy</dependency> from the dependency list
      int driverDependencyindex = deployDependencies.getChildNodes().getLength()
            - 3;
      Node driverDependency = deployDependencies.getChildNodes()
            .item(driverDependencyindex);

      // Insert the new module before driver dependency
      deployDependencies.insertBefore(newDependency, driverDependency);

      // rewrite the old pom with the new updated pom
      utils.transformXML(deployPom, tckDirectory + DEPLOY_POM_PATH);

      System.out.println(
            "Successfully added following XML to portlet-tck_3.0/deploy/pom.xml - "
                  + debugTools.dependencyToString(newDependency));
   }

   /**
    * Adds the new module to TCK POM
    */
   private static void addModuleToTckPom(Document tckPom)
         throws TransformerException {
      System.out.println("\n");

      // Get the modules list i.e. - "<modules></modules>" element of the pom
      Node tckModules = tckPom.getElementsByTagName("modules").item(0);

      // Make a new "<module>newModule</module>" tag
      Element newModule = tckPom.createElement("module");
      newModule.setTextContent(moduleName);

      // Get the <module>deploy</module> from the modules list
      int deployModuleindex = tckModules.getChildNodes().getLength() - 5;
      Node deployModule = tckModules.getChildNodes().item(deployModuleindex);

      // Insert the new module before deploy module
      tckModules.insertBefore(newModule, deployModule);

      // rewrite the old pom with the new updated pom
      utils.transformXML(tckPom, tckDirectory + TCK_POM_PATH);

      System.out.println(
            "Successfully added following XML to portlet-tck_3.0/pom.xml - "
                  + debugTools.moduleToString(newModule));
   }

}